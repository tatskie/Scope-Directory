<template>
  <div class="table-tr">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'TblRow'
}
</script>
