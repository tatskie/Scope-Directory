<template>
	<div class="col-md-12">
    <my-account></my-account>
  </div>
</template>

<script>
  import MyAccount from './my-account/MyAccount';

  export default {
      components:{
          "my-account":MyAccount
      }  
  }
</script>
