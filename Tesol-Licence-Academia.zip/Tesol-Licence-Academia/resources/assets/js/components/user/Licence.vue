<template>
	<div class="col-md-12">
       <card></card>
    </div>
</template>

<script>
    import Card from './license/card';

    export default {
        components:{
            "card":Card
        }  
    }
</script>
