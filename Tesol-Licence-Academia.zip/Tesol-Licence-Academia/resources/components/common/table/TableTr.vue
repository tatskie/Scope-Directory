<template>
  <div class="table__tr">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'TblRow'
}
</script>
