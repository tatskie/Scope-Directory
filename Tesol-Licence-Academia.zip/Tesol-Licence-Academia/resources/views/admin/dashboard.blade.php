@extends('admin.layouts.app')

@section('title')
    Admin Dashboard
@endsection

@section('content')

<router-view></router-view>

@endsection
