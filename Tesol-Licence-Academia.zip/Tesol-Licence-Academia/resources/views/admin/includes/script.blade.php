<script src="{{ asset('assets/js/app.js') }}" defer></script>
