<script src="{{ asset('assets/js/academia.js') }}" defer></script>


