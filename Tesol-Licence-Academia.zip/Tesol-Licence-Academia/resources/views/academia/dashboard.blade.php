@extends('academia.layouts.app')

@section('title')
    myTESOL
@endsection

@section('content')

<router-view></router-view>

@endsection
