<script src="{{ asset('assets/js/teacher.js') }}" defer></script>


