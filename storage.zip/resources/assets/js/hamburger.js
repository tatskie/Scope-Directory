let hamburger = document.getElementById("js-hamburger");
let navigation = document.getElementById('js-navigation');


hamburger.onclick = function() {myFunction()};

function myFunction() {
  console.log("click");
};