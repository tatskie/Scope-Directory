<?php $__env->startSection('title'); ?>
    myTESOL
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<router-view></router-view>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('academia.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Academia\resources\views/academia/dashboard.blade.php ENDPATH**/ ?>