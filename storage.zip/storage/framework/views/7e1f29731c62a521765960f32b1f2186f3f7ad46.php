<?php $__env->startSection('pages'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($page->Subpages) >= 1): ?>
            <li class="navigation-item">
                <a class="navigation-link" href="<?php echo e(route('register')); ?>">
                  <span><?php echo e($page->title); ?></span>
                </a>

                <ul class="navigation-sub">
                    <?php $__currentLoopData = $page->Subpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="navigation-sub-item">
                        <a href="<?php echo e(url('/pages/'.$page->slug .'/subpages/'. $subPage->slug)); ?>" class="navigation-sub-link">
                          <span><?php echo e($subPage->title); ?></span>
                        </a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php else: ?>
        <li class="navigation-item">
            <a class="navigation-link" href="<?php echo e(url('/pages/'. $page->slug)); ?>"><?php echo e($page->title); ?></a>
        </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  <div class="subpage">
    <div class="subpage-title">
      <div class="subpage-title-inner">
        <h1>Create an Account</h1>
      </div>
    </div>

    <div class="l-container">

      <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
      
      <p class="subpage-text">Registering for this site is easy. Just fill in the fields below, and we'll get a new account set up for you in no time.</p>

      <div class="form-wrap">
        <form class="form-prevent-multiple-submits" method="POST" action="<?php echo e(route('register')); ?>">
          <?php echo csrf_field(); ?>

          <div class="form-inner">
            <div class="form-con">
              <h2 class="form-title">Account Details</h2>

              <div class="form-input">
                <label class="form-lbl" for="username">
                  <span><?php echo e(__('Username')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                  <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username">
                </div>

                <?php if($errors->has('username')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('username')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="email">
                  <span><?php echo e(__('E-Mail Address')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                  <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                </div>

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="password">
                  <span><?php echo e(__('Password')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                   <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                </div>

                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>

                <span class="form-note" style="color: #39c8df;">Your password must be more than 8 characters long, should contain at-least 1 Uppercase, 1 Lowercase, 1 Numeric and 1 special character.</span>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="password-confirm">
                  <span><?php echo e(__('Confirm Password')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                  <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                </div>
                
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="name">
                  <span><?php echo e(__('Captcha')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="g-recaptcha" data-sitekey="<?php echo e(env('NOCAPTCHA_SITEKEY')); ?>"></div>

                <?php if($errors->has('g-recaptcha-response')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

            </div>

            <div class="form-con">
              <h2 class="form-title">Profile Details</h2>

              <div class="form-input">
                <label class="form-lbl" for="name">
                  <span style="color: #EE6446;"><?php echo e(__('Name')); ?></span><span class="form-required" style="color: #EE6446;"> (required)</span>
                </label>

                <div class="form-input-box">
                  <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                </div>

                <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>

                <span class="form-note" style="color: #39c8df;">This name will appear on your license card.</span>
              </div>

              <!-- <div class="form-input">
                <label class="form-lbl" for="account_type">
                  <span><?php echo e(__('Register as')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                  <select id="account_type" name="account_type">
                      <option value="teacher">Teacher</option>
                      <option value="undergrad">Undergraduate</option>
                      <option value="academia">Academia</option>
                  </select>
                  </div>

                <?php if($errors->has('account_type')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('account_type')); ?></strong>
                    </span>
                <?php endif; ?>
              </div> -->

            </div>
          </div>

          <button type="submit" class="btn btn-gradient btn-register button-prevent-multiple-submits">
            <span class="btn-text">
              <i class="spinner fa fa-spinner fa-spin" style="display: none;"></i>
              <!-- <?php echo e(__('Register')); ?> -->
              <?php echo e(__('Complete Sign up')); ?>

            </span>
          </button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Academia\resources\views/auth/register.blade.php ENDPATH**/ ?>