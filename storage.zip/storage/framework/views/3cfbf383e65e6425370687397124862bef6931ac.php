<script src="<?php echo e(asset('assets/js/teacher.js')); ?>" defer></script>


<?php /**PATH C:\xampp\htdocs\Tesol\resources\views/teacher/includes/script.blade.php ENDPATH**/ ?>