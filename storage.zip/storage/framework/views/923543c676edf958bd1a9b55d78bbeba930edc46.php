<?php $__env->startSection('pages'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(count($page->Subpages) >= 1): ?>
            <li class="navigation-item">
                <a class="navigation-link" href="<?php echo e(route('register')); ?>">
                  <span><?php echo e($page->title); ?></span>
                </a>

                <ul class="navigation-sub">
                    <?php $__currentLoopData = $page->Subpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="navigation-sub-item">
                        <a href="<?php echo e(url('/pages/'.$page->slug .'/subpages/'. $subPage->slug)); ?>" class="navigation-sub-link">
                          <span><?php echo e($subPage->title); ?></span>
                        </a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php else: ?>
        <li class="navigation-item <?php echo e(Request::url() == url('/pages/'. $page->slug ) ? 'is-active' : ''); ?>">
            <a class="navigation-link" href="<?php echo e(url('/pages/'. $page->slug)); ?>"><?php echo e($page->title); ?></a>
        </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="subpage">
  <div class="subpage-title">
    <div class="subpage-title-inner">
      <h1>Tesol License Card Form</h1>
    </div>
  </div>


  <div class="subpage-inner">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <div class="l-container">
      <div class="form-wrap">
        <form class="form-prevent-multiple-submits" method="POST" action="<?php echo e(route('create.card')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <div class="form-inner">
            <div class="form-con">

              <div class="form-input">
                <label class="form-lbl" for="gender">
                  <span><?php echo e(__('Gender')); ?></span><!-- <span class="form-required"> (optional)</span> -->
                </label>

                <div class="form-input-box">
                  <select class="custom-select" id="gender" name="gender">
                    <option value="">-- select one --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="NS">NS</option>
                  </select>
                </div>

                <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
                <span class="form-error">
                  <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="title">
                  <span><?php echo e(__('Title')); ?></span>
                </label>

                <div class="form-input-box">
                  <input id="title" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title" autocomplete="title" placeholder="Mr. Mrs. Ms. Dr. Prof. Blank">
                </div>

                <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                <span class="form-error">
                  <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="citizenship">
                  <span><?php echo e(__('Citizenship')); ?></span><span class="form-required"> (optional)</span>
                </label>

                <div class="form-input-box">
                  <select name="citizenship">
                    <option value="">-- select one --</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($country->nationality); ?>"><?php echo e($country->nationality); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                <?php if ($errors->has('citizenship')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('citizenship'); ?>
                <span class="form-error">
                  <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

            </div>

            <div class="form-con">

              <div class="form-input">
                <label class="form-lbl" for="name">
                  <span><?php echo e(__('Name')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                  <input onchange="disableInput()" id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" required autocomplete="name" value="<?php echo e(auth()->user()->name); ?>" required readonly>
                </div>

                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                <span class="name-error form-error">
                  <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                <span class="input-empty-error form-error" style="color: red; display: none;">
                  Name cannot be empty!
                </span>

                <span class="form-note">This name will appear on your license card.</span>
                <span class="form-note"><a onclick="changeName()" href="#">Please click to change Name</a></span>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="photo">
                  <span><?php echo e(__('License Card Photo')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="form-input-box">
                  <input type="file" class="form-control-file" id="photo" name="photo">
                </div>

                <span class="form-note" style="color: #39c8df;">File format: JPG or PNG, not more than 2MB in file size.</span>
                <?php if ($errors->has('photo')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('photo'); ?>
                <span class="form-error">
                  <?php echo e($message); ?>

                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

            </div>
          </div>

          <button type="submit" class="btn btn-gradient btn-register button-prevent-multiple-submits">
            <span class="btn-text">
              <i class="spinner fa fa-spinner fa-spin" style="display: none;"></i>
              <?php echo e(__('Complete Application')); ?>

            </span>
          </button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
    function changeName() {
      $('#name').attr("readonly", false).focus();
      $('.input-empty-error').hide();
    }

    function disableInput() {
      var name = $('#name').val().length;

      $('.name-error').hide();

      if (name == 0) {
        $('.input-empty-error').show();
        $('#name').attr("readonly", false).focus();
      }else {
        $('.input-empty-error').hide();
        $('#name').attr("readonly", true);
      }
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Academia\resources\views/license/index.blade.php ENDPATH**/ ?>