<!-- Fonts -->
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

<!-- Styles -->
<link href="<?php echo e(asset('assets/css/admin.css')); ?>" rel="stylesheet">
<?php /**PATH C:\xampp\htdocs\Academia\resources\views/academia/includes/styles.blade.php ENDPATH**/ ?>