<script src="<?php echo e(asset('assets/js/academia.js')); ?>" defer></script>


<?php /**PATH C:\xampp\htdocs\Academia\resources\views/academia/includes/script.blade.php ENDPATH**/ ?>