<?php $__env->startSection('pages'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(count($page->Subpages) >= 1): ?>
            <li class="navigation-item">
                <a class="navigation-link" href="<?php echo e(route('register')); ?>">
                  <span><?php echo e($page->title); ?></span>
                </a>

                <ul class="navigation-sub">
                    <?php $__currentLoopData = $page->Subpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="navigation-sub-item">
                        <a href="<?php echo e(url('/pages/'.$page->slug .'/subpages/'. $subPage->slug)); ?>" class="navigation-sub-link">
                          <span><?php echo e($subPage->title); ?></span>
                        </a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php else: ?>
        <li class="navigation-item">
            <a class="navigation-link" href="<?php echo e(url('/pages/'. $page->slug)); ?>"><?php echo e($page->title); ?></a>
        </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="subpage">

  <div class="subpage-title">
    <div class="subpage-title-inner">
      <h1>Welcome <?php echo e(ucwords(auth()->user()->name )); ?></h1>
    </div>
  </div>


  <div class="subpage-inner">

    <div class="subpage-content">
      <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>
      There are <?php echo e($total); ?> questions. They have been assembled by TESOL experts with over a century of combined experience in the TESOL profession.
      <br>
      <br>
      Please answer all of the questions in order to calculate your Professional TESOL Registered Standing level. You cannot proceed from one question to the next if you do not answer. Once you complete the application you can see your TESOL level.
      <br>
      <br>
      There are two sets of questions. The first set relates to your experience and qualifications. The second set relates to any volunteer work you have done.
      <br>
      <br>
      After competing all questions you will see your two scores:-
      <br>
      <br>
        <p>&nbsp;&nbsp;&nbsp;1.) TESOL level – ranging from 1 -10</p>
        <p>&nbsp;&nbsp;&nbsp;2.) Your Volunteer service level based on Bronze-Silver-Gold-Platinum (Teacher Impact factor – TIF)</p>
      <br>

      Note:-. Data security is of primary importance. Whilst we have taken all steps to protect your data on our Servers, we ask that you do not provide any information that is not already on the internet. Thus some questions below are optional - (such as country of citizenship)
      <br>
      <br>
      The questions lead to two options:-
      <br>
      <br>
      <strong>Free option :-</strong> Your TESOL Professional Summary on line (secured) with print out of your input.
      <br>
      <strong>Paid option :-</strong> :- A beautiful wallet size hard copy <a href="https://www.tesol-licence.education/teachers/" target="_blank">(see samples)</a> that will be produced and delivered to you. The QR card on your card reverts to your. TESOL Professional Summary.
      <br>
      <br>
      a) Your hard copy card will contain your name, your photo, and your TESOL Professional Standing.
      <br>
      <br>
      1) See sample cards. <a href="https://www.tesol-licence.education/teachers/" target="_blank">click here.</a>
      <br>
      <br>
      2) The system will produce a (Resume) page based on your data input which can be accessed by only you either by scanning the QR code on your Card or by signing in. This information can be updated as you upgrade your skills.
      <br>
      <br>
      3) Before you answer the questions: -
      <br>
      <br>
          <p>&nbsp;&nbsp;&nbsp;1. This may take up to 30 - 45 minutes to complete.</p>
          <p>&nbsp;&nbsp;&nbsp;2. If you cannot complete the questions you will have to re-login another time.</p>
          <p>&nbsp;&nbsp;&nbsp;3. You do not need to provide documentary evidence unless subsequently required to confirm an answer.</p>
          <p>&nbsp;&nbsp;&nbsp;4. Some questions will ask you about your TESOL Conference attendance history and publication history, so it is a good idea to have your</p>
          <p>&nbsp;&nbsp;&nbsp;records on hand prior to starting the questions.</p>
          <p>&nbsp;&nbsp;&nbsp;5. You should also have access to your photo in your computer which will be uploaded.</p>
          <p>&nbsp;&nbsp;&nbsp;6. If you log off before completing the questions you will need to return to Question 1 on your subsequent return. We do not store</p>
          <p>&nbsp;&nbsp;&nbsp;incomplete attempts.</p>
          <p>&nbsp;&nbsp;&nbsp;7. Note that there are three options for you once you have agreed to and completed all steps;-</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(a) keep your record for free in our server (not accessible except to you with your log-in data)</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(b) you can also opt for the paid version of the card, the sample of which you can view here in.</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The fee to produce that is US$65.00 plus delivery fee (set by FEDX or DHL) and that fee will
          depend on your location.</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Paypal is the medium of currency exchange.</p>
          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(c) you may opt to delete all your data.</p>
          <p>&nbsp;&nbsp;&nbsp;8. Your data is recorded in your online account so it is important to take care of spelling and grammatical matters. However, If you do</p>
          <p>&nbsp;&nbsp;&nbsp;enter something that needs correcting, you do have an option at the end to correct this data.</p>
      <br>
      <br>
      <br>
      <div class="btn btn-gradient-link btn-mv" style="height: 50%;">
        <form class="form-prevent-multiple-submits" method="POST" action="<?php echo e(route('update.score')); ?>">

        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>


        <input type="checkbox" id="is_agree" name="is_agree" value="1">
        <label for="is_agree">The answers I shall give shall be true to the best of my knowledge.</label>
        <?php if($errors->has('is_agree')): ?>
            <br>
            <span class="help-block">
                <strong style="color: red;">This field is required!</strong>
            </span>
        <?php endif; ?>
        <br>
        <br>
        <button class="btn-link" type="submit">
          <span><i class="spinner fa fa-spinner fa-spin" style="display: none;"></i>Proceed</span>
        </button>

        </form>
      </div>
    </div>

    <div class="subpage-sidebar">

      </div>
  </div>
</div>
<br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tesol\resources\views/teacher/welcome-user.blade.php ENDPATH**/ ?>