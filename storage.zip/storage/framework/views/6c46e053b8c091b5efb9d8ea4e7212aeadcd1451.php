<header class="l-header">
  <div class="header" id="header">
    <div class="logo">
      <a href="<?php echo e(url('https://www.tesol-licence.education')); ?>">
        <img src="../assets/images/common/tle-logo2.png" alt="">
      </a>
    </div>

    <div class="header-menu">
      <div class="navigation-wrap" id="js-navigation">
        <div class="navigation">
          <ul class="navigation-inner">
          
            <li class="navigation-item <?php echo e(Request::url() == url('/home') ? 'is-active' : ''); ?>">
              <a href="<?php echo e(url('https://www.tesol-licence.education/')); ?>" class="navigation-link">
                <span>Home</span>
              </a>
            </li>
          
            <li class="navigation-item <?php echo e(Request::url() == url('/home') ? 'is-active' : ''); ?>">
              <a href="<?php echo e(url('https://my.tesol-licence.education/')); ?>" class="navigation-link">
                <span><i style="font-size:95%; text-transform:lowercase">my</i><span style="margin-left:2px;">TESOL</span></span>
              </a>
            </li>

            <?php echo $__env->yieldContent('pages'); ?>
          </ul>

          <div class="navigation-auth">
            <?php if(auth()->guard()->guest()): ?>
              <div class="btn-auth" >
                <a class="btn-link " href="<?php echo e(route('login')); ?>">
                  <span><?php echo e(__('Login')); ?></span>
                </a>
              </div>
              <?php if(Route::has('register')): ?>
                <div class="btn-auth">
                  <a class="btn-link" href="<?php echo e(route('register')); ?>">
                    <span><?php echo e(__('Register')); ?></span>
                  </a>
                </div>
              <?php endif; ?>
            <?php else: ?>

            <?php endif; ?>
          </div>
        </div>
      </div>

   		<div class="header-btn">
         <div class="btn btn-cart">
          <i class="ico-cart"></i>
          <span>0</span>
        </div>

<!--      <div class="btn btn-search">
          <i class="ico-search"></i>
        </div>
-->
        <?php if(auth()->guard()->guest()): ?>
<!--        <div class="btn btn-profile ">
            <a class="btn-link " href="<?php echo e(route('login')); ?>">
              <i style="font-size:20px" class="ico-user-o"></i>
            </a>
       </div>
-->      
        <?php else: ?>
          <div class="btn btn-logout ">
            <a class="btn-link " href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <div class="navigation-item"><span class="navigation-link">Logout</span></div><i class="ico-logout"></i>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
              </form>
            </a>
          </div>
        <?php endif; ?>
      </div>

      <div class="header-auth">
        <?php if(auth()->guard()->guest()): ?>
          <div class="btn-auth" >
            <a class="btn-link " href="<?php echo e(route('login')); ?>">
              <span><?php echo e(__('Login')); ?></span>
            </a>
          </div>
          <?php if(Route::has('register')): ?>
            <div class="btn-auth">
              <a class="btn-link" href="<?php echo e(route('register')); ?>">
                <span><?php echo e(__('Register')); ?></span>
              </a>
            </div>
          <?php endif; ?>
        <?php else: ?>

        <?php endif; ?>
      </div>

      <div class="hamburger-wrap" id="js-hamburger">
        <div class="hamburger"></div>
      </div>
    </div>


  </div>
</header>
<?php /**PATH C:\xampp\htdocs\Tesol\resources\views/layouts/header.blade.php ENDPATH**/ ?>