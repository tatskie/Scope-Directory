<?php $__env->startSection('content'); ?>
<div class="subpage">

  <div class="subpage-title">
    <div class="subpage-title-inner">
      <h1>This page isn't available. NOT FOUND (404)</h1>
    </div>
  </div>


  <div class="subpage-inner">

    <div class="subpage-content subpage-body">
      <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>

      The requested operation failed because a resource associated with the request could not be found.
    </div>

    <div class="subpage-sidebar">

      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tesol\resources\views/errors/404.blade.php ENDPATH**/ ?>