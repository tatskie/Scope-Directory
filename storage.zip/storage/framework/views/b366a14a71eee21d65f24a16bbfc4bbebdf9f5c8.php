<div class="navigation">

  <?php if(auth()->guard()->guest()): ?>
    <div class="navigation-item">
      <a class="navigation-link" href="<?php echo e(route('login')); ?>">
        <span><?php echo e(__('Login')); ?></span>
      </a>
    </div>

    <?php if(Route::has('register')): ?>
    <div class="navigation-item">
      <a class="navigation-link" href="<?php echo e(route('login')); ?>">
        <span><?php echo e(__('Register')); ?></span>
      </a>
    </div>
    <?php endif; ?>
  <?php else: ?>
    <div class="navigation-item">
      <router-link class="navigation-link" to="/academia/dashboard">
        <i class="ico-theme"></i>
        <span><i style="font-size:95%">my</i><span style="margin-left:-8px">TESOL</span></span>
      </router-link>
    </div>
    <div class="navigation-item">
      <router-link class="navigation-link" to="/academia/licence">
        <i class="ico-welcome"></i>
        <span>Your Licence</span>
      </router-link>
    </div>
    <!-- <div class="navigation-item">
      <router-link class="navigation-link" to="/academia/level">
        <i class="ico-questionnaire"></i>
        <span>Upgrade your Level</span>
      </router-link>
    </div> -->
    <div class="navigation-item">
      <router-link class="navigation-link" to="#" href="<?php echo e(route('logout')); ?>"
         onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="ico-logout"></i>
        <span>Logout</span>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
      </router-link>
    </div>
  <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\Academia\resources\views/academia/includes/navigation.blade.php ENDPATH**/ ?>