<?php $__env->startSection('pages'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if(count($page->Subpages) >= 1): ?>
            <li class="navigation-item">
                <a class="navigation-link" href="<?php echo e(route('register')); ?>">
                  <span><?php echo e($page->title); ?></span>
                </a>

                <ul class="navigation-sub">
                    <?php $__currentLoopData = $page->Subpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="navigation-sub-item">
                        <a href="<?php echo e(url('/pages/'.$page->slug .'/subpages/'. $subPage->slug)); ?>" class="navigation-sub-link">
                          <span><?php echo e($subPage->title); ?></span>
                        </a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php else: ?>
        <li class="navigation-item <?php echo e(Request::url() == url('/pages/'. $page->slug ) ? 'is-active' : ''); ?>">
            <a class="navigation-link" href="<?php echo e(url('/pages/'. $page->slug)); ?>"><?php echo e($page->title); ?></a>
        </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="subpage">
  <div class="subpage-title">
    <div class="subpage-title-inner">
      <h1>Congratulations <?php echo e(ucwords(auth()->user()->name)); ?>!</h1>
    </div>
  </div>


  <div class="subpage-inner">
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <div class="l-container">
      <div class="form-wrap">
        <p><strong>Classifications</strong></p>
        <br>
        <table width="100%">
          <tbody>
            <tr>
              <td></td>
              <td colspan="3" width="545"></td>
            </tr>
            <tr>
              <td width="72">#</td>
              <td width="313">TESOL Teacher/Staff&nbsp; Specialist Title</td>
              <td width="96">Class</td>
              <td width="136"></td>
            </tr>
            <tr>
              <td width="72"></td>
              <td width="313"></td>
              <td width="96"></td>
              <td width="136"></td>
            </tr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td width="72"><?php echo e($category->number); ?>.</td>
                <td width="313"><?php echo e(ucwords($category->specialist_title)); ?></td>
                <td width="96" style="color: blue;">Class <?php echo e($category->class); ?></td>
                <td width="136"></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
          </tbody>
        </table>  
      </div>
      <br>
      <div class="form-wrap">
          <div class="form-inner">
            <div class="form-con">
              <h1>You are assessed at Category, <strong style="color: red;">L<?php echo e($data->number); ?> <?php echo e(ucwords($data->specialist_title)); ?></strong></h1>
            </div>
          </div>
          <br>

          <?php if(auth()->user()->answerScore->is_done_tif == true): ?>
            <div class="form-inner">
              <div class="form-con">
                <h1>You are assessed at Teacher Impact Factor, <strong style="color: red;"><?php echo e(ucwords($dataPif->title)); ?></strong></h1>
              </div>
            </div>
            <br>
          <?php endif; ?>

          <?php if(auth()->user()->answerScore->is_done_tif == true): ?>
            <form class="proceed-form-prevent-multiple-submits" method="POST" action="<?php echo e(route('user.proceed')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
              <input type="hidden" name="proceed_answer" value="1">
              <button type="submit" class="btn btn-gradient btn-register button-prevent-multiple-submits">
                <span class="btn-text">
                  <i class="proceed-spinner fa fa-spinner fa-spin" style="display: none;"></i>
                  <?php echo e(__('PROCEED')); ?>

                </span>
              </button>
            </form>
            <br>
          <?php endif; ?>

          <?php if(auth()->user()->answerScore->is_done_tif == false): ?>
          <form class="pif-form-prevent-multiple-submits" method="POST" action="<?php echo e(route('pif.question')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <input type="hidden" name="proceed_pif" value="1">
            <p>The next set of questions relate to any  volunteer / community work you have undertaken" - Teacher Impact Factor Questions</p>
            <br>
            <button type="submit" class="btn btn-gradient btn-register button-prevent-multiple-submits">
              <span class="btn-text">
                <i class="pif-spinner fa fa-spinner fa-spin" style="display: none;"></i>
                <?php echo e(__('Take TIF Questions')); ?>

              </span>
            </button>
          </form>
          <br>
          <?php else: ?>
          <?php endif; ?>
          <!-- <form class="form-prevent-multiple-submits" method="POST" action="#" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <p>Or you may wish to re-take the Assessment</p>
          <input type="hidden" name="reset_answer" value="1">
          <button type="submit" class="btn btn-gradient btn-register button-prevent-multiple-submits">
            <span class="btn-text">
              <i class="spinner fa fa-spinner fa-spin" style="display: none;"></i>
              <?php echo e(__('RE-TAKE ASSESSMENT')); ?>

            </span>
          </button>
        </form> -->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Academia\resources\views/license/congratulations.blade.php ENDPATH**/ ?>