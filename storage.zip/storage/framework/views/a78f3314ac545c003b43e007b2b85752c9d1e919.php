<?php $__env->startSection('pages'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($page->Subpages) >= 1): ?>
            <li class="navigation-item">
                <a class="navigation-link" href="<?php echo e(route('register')); ?>">
                  <span><?php echo e($page->title); ?></span>
                </a>

                <ul class="navigation-sub">
                    <?php $__currentLoopData = $page->Subpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="navigation-sub-item">
                        <a href="<?php echo e(url('/pages/'.$page->slug .'/subpages/'. $subPage->slug)); ?>" class="navigation-sub-link">
                          <span><?php echo e($subPage->title); ?></span>
                        </a>
                      </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php else: ?>
        <li class="navigation-item <?php echo e(Request::url() == url('/pages/'. $page->slug ) ? 'is-active' : ''); ?>">
            <a class="navigation-link" href="<?php echo e(url('/pages/'. $page->slug)); ?>"><?php echo e($page->title); ?></a>
        </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="subpage">
    <!--     <div class="subpage-title">
      <div class="subpage-title-inner">
        <h1>Create an Account</h1>
      </div>
    </div> -->

    <div class="l-container">
      <?php if(session('status')): ?>
        <div class="alert alert-success">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>
      <?php if(session('warning')): ?>
        <div class="alert alert-warning">
          <?php echo e(session('warning')); ?>

        </div>
      <?php endif; ?>
      <?php if(session('message')): ?>
        <div class="alert alert-warning">
          <?php echo e(session('message')); ?>

        </div>
      <?php endif; ?>
      <div class="form-wrap form-login">
        <form class="form-prevent-multiple-submits" method="POST" action="<?php echo e(route('login')); ?>">

          <?php echo csrf_field(); ?>

          <div class="form-inner">

            <div class="form-con">
              <div class="form-input">
                <div class="form-input-box">
                  <input id="text" type="text" class="form-control <?php echo e($errors->has('username') || $errors->has('email') ? ' is-invalid' : ''); ?>" name="login" value="<?php echo e(old('username') ?: old('email')); ?>" required autofocus placeholder="Username or Email">
                </div>

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>

                <?php if($errors->has('username')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('username')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-input">
                <div class="form-input-box">
                  <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password" placeholder="Password">
                </div>

                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>

              <div class="form-input">
                <label class="form-lbl" for="name">
                  <span><?php echo e(__('Captcha')); ?></span><span class="form-required"> (required)</span>
                </label>

                <div class="g-recaptcha" data-sitekey="<?php echo e(env('NOCAPTCHA_SITEKEY')); ?>"></div>

                <?php if($errors->has('g-recaptcha-response')): ?>
                    <span class="help-block">
                        <strong style="color: #EE6446;"><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
              
              <button type="submit" class="btn btn-gradient btn-login button-prevent-multiple-submits">
                <span class="btn-text">
                  <i class="spinner fa fa-spinner fa-spin" style="display: none;"></i>
                  <!-- <?php echo e(__('Register')); ?> -->
                  <?php echo e(__('Sign In')); ?>

                </span>
              </button>

              <div class="form-extra">
                <div class="form-check">
                  <input class="form-check" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                  <label for="remember"><?php echo e(__('Remember Me')); ?></label>
                </div>
                <a class="form-extra-link form-extra-link-register" href="<?php echo e(route('register')); ?>">
                  <i class="ico-edit"></i>
                  <span><?php echo e(__('Register?')); ?></span>
                </a>

                <?php if(Route::has('password.request')): ?>
                  <a class="form-extra-link" href="<?php echo e(route('password.request')); ?>">
                    <i class="ico-lost-pass"></i>
                    <span><?php echo e(__('Lost Password?')); ?></span>
                  </a>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-con">

              <h2 class="form-title">Sign In With: </h2>

              <div class="btn btn-login btn-login-linkedin">
                <a href="<?php echo e(route('login.linkedin')); ?>" class="btn-link">
                  <i class="fa fa-linkedin" style="font-size: 16px;font-weight: normal;"></i>
                  <span><?php echo e(__('Sign in with Linkedin')); ?></span>
                </a>
              </div>
              
              <div class="btn btn-login btn-login-fb">
                <a href="<?php echo e(route('login.facebook')); ?>" class="btn-link">
                  <i class="ico-fb"></i>
                  <span><?php echo e(__('Sign in with Facebook')); ?></span>
                </a>
              </div>

              <div class="btn btn-login btn-login-google">
                <a href="<?php echo e(route('login.google')); ?>" class="btn-link">
                  <i class="ico-google"></i>
                  <span><?php echo e(__('Sign in with Google')); ?></span>
                </a>
              </div>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Academia\resources\views/auth/login.blade.php ENDPATH**/ ?>